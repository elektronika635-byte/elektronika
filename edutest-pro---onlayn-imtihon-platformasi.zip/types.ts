
export enum Role {
  ADMIN = 'admin',
  TEACHER = 'teacher',
  STUDENT = 'student'
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  studentLimit: number;
  testLimit: number;
}

export interface User {
  id: string;
  name: string;
  username: string;
  password?: string;
  role: Role;
  phone?: string;
  documentSeries?: string; // Passport or Birth Certificate
  teacherId?: string;
  passwordChanged?: boolean;
  planId?: string;
  isActive?: boolean;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Test {
  id: string;
  title: string;
  description: string;
  teacherId: string;
  questions: Question[];
  createdAt: number;
}

export interface Attempt {
  id: string;
  testId: string;
  studentId: string;
  score: number;
  total: number;
  timestamp: number;
}

export interface AppState {
  users: User[];
  tests: Test[];
  attempts: Attempt[];
  plans: Plan[];
  currentUser: User | null;
}
