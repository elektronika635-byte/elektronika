
import React, { useState, useEffect } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { AppState, User, Role, Plan } from './types';
import Login from './views/Login';
import TeacherDashboard from './views/TeacherDashboard';
import StudentDashboard from './views/StudentDashboard';
import AdminDashboard from './views/AdminDashboard';
import TakeTest from './views/TakeTest';
import Certificate from './views/Certificate';
import Navbar from './components/Navbar';
import ChangePassword from './views/ChangePassword';

const { HashRouter, Routes, Route, Navigate } = ReactRouterDOM;

const INITIAL_PLANS: Plan[] = [
  { id: 'free', name: 'Bepul', price: 0, studentLimit: 10, testLimit: 5 },
  { id: 'pro', name: 'Pro', price: 100000, studentLimit: 100, testLimit: 50 },
  { id: 'ultra', name: 'Ultra', price: 500000, studentLimit: 1000, testLimit: 999 }
];

const INITIAL_STATE: AppState = {
  users: [
    { id: 'admin-1', name: 'Asosiy Admin', username: 'admin', password: '123', role: Role.ADMIN, isActive: true },
    { id: 't1', name: 'Ali O\'qituvchi', username: 'ali', password: '123', role: Role.TEACHER, planId: 'free', isActive: true, passwordChanged: true }
  ],
  tests: [],
  attempts: [],
  plans: INITIAL_PLANS,
  currentUser: null
};

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('edutest_pro_v2_final');
    return saved ? JSON.parse(saved) : INITIAL_STATE;
  });

  useEffect(() => {
    localStorage.setItem('edutest_pro_v2_final', JSON.stringify(state));
  }, [state]);

  const updateState = (updater: (prev: AppState) => AppState) => setState(prev => updater(prev));
  const login = (user: User) => setState(prev => ({ ...prev, currentUser: user }));
  const logout = () => setState(prev => ({ ...prev, currentUser: null }));

  const needsPasswordChange = state.currentUser?.role === Role.STUDENT && !state.currentUser?.passwordChanged;

  return (
    <HashRouter>
      <div className="min-h-screen bg-slate-50">
        <Navbar currentUser={state.currentUser} onLogout={logout} />
        
        <main className="container mx-auto px-4 py-8">
          {needsPasswordChange ? (
            <ChangePassword updateState={updateState} currentUser={state.currentUser!} />
          ) : (
            <Routes>
              <Route path="/login" element={
                state.currentUser ? (
                  <Navigate to={
                    state.currentUser.role === Role.ADMIN ? "/admin" : 
                    state.currentUser.role === Role.TEACHER ? "/teacher" : "/student"
                  } />
                ) : (
                  <Login users={state.users} onLogin={login} updateState={updateState} />
                )
              } />
              
              <Route path="/admin/*" element={state.currentUser?.role === Role.ADMIN ? <AdminDashboard state={state} updateState={updateState} /> : <Navigate to="/login" />} />
              <Route path="/teacher/*" element={state.currentUser?.role === Role.TEACHER ? <TeacherDashboard state={state} updateState={updateState} /> : <Navigate to="/login" />} />
              <Route path="/student/*" element={state.currentUser?.role === Role.STUDENT ? <StudentDashboard state={state} /> : <Navigate to="/login" />} />
              <Route path="/test/:id" element={state.currentUser?.role === Role.STUDENT ? <TakeTest state={state} updateState={updateState} /> : <Navigate to="/login" />} />
              <Route path="/certificate/:attemptId" element={<Certificate state={state} />} />
              
              <Route path="/" element={<Navigate to="/login" />} />
            </Routes>
          )}
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
