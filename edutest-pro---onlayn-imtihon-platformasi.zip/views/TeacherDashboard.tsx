
import React, { useState } from 'react';
import { AppState, User, Role, Test, Question, Plan } from '../types';
import * as ReactRouterDOM from 'react-router-dom';

const { Link } = ReactRouterDOM;

interface TeacherDashboardProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ state, updateState }) => {
  const [activeTab, setActiveTab] = useState<'students' | 'tests' | 'results' | 'billing'>('tests');
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [isCreatingTest, setIsCreatingTest] = useState(false);
  
  const [newStudent, setNewStudent] = useState({ name: '', phone: '', documentSeries: '' });
  const [newTest, setNewTest] = useState<Partial<Test>>({ title: '', questions: [] });

  const teacher = state.currentUser!;
  const plan = state.plans.find(p => p.id === teacher.planId) || state.plans[0];

  const myStudents = state.users.filter(u => u.teacherId === teacher.id);
  const myTests = state.tests.filter(t => t.teacherId === teacher.id);
  const myResults = state.attempts.filter(a => state.tests.find(t => t.id === a.testId)?.teacherId === teacher.id);

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (myStudents.length >= plan.studentLimit) {
      alert(`Sizning tarifingizda limit to'lgan (${plan.studentLimit} ta o'quvchi). Iltimos tarifni yangilang.`);
      return;
    }
    
    // Generate credentials
    const username = newStudent.name.toLowerCase().replace(/\s+/g, '') + Math.floor(1000 + Math.random() * 9000);
    const tempPassword = Math.floor(100000 + Math.random() * 899999).toString();

    const student: User = {
      id: Date.now().toString(),
      name: newStudent.name,
      username,
      password: tempPassword,
      phone: newStudent.phone,
      documentSeries: newStudent.documentSeries,
      role: Role.STUDENT,
      teacherId: teacher.id,
      passwordChanged: false
    };

    updateState(prev => ({ ...prev, users: [...prev.users, student] }));
    alert(`O'quvchi qo'shildi!\nLogin: ${username}\nParol: ${tempPassword}\n(O'quvchi kirganda parolni o'zgartirishi shart)`);
    setIsAddingStudent(false);
    setNewStudent({ name: '', phone: '', documentSeries: '' });
  };

  const addManualQuestion = () => {
    const q: Question = {
      id: Math.random().toString(),
      text: '',
      options: ['', '', '', ''],
      correctAnswer: 0
    };
    setNewTest(prev => ({ ...prev, questions: [...(prev.questions || []), q] }));
  };

  const handleSaveTest = () => {
    if (!newTest.title || !newTest.questions?.length) return;
    const test: Test = {
      id: Date.now().toString(),
      title: newTest.title,
      description: '',
      teacherId: teacher.id,
      questions: newTest.questions as Question[],
      createdAt: Date.now()
    };
    updateState(prev => ({ ...prev, tests: [...prev.tests, test] }));
    setIsCreatingTest(false);
    setNewTest({ title: '', questions: [] });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Assalomu alaykum, {teacher.name}</h1>
          <p className="text-slate-500">Tarif: <span className="font-bold text-indigo-600">{plan.name}</span> | O'quvchilar: {myStudents.length}/{plan.studentLimit}</p>
        </div>
        <div className="flex bg-white p-1 rounded-xl shadow-sm border">
          {(['tests', 'students', 'results', 'billing'] as const).map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === tab ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'}`}
            >
              {tab === 'tests' ? 'Testlar' : tab === 'students' ? 'O\'quvchilar' : tab === 'results' ? 'Natijalar' : 'To\'lov'}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'tests' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Testlar Ro'yxati</h2>
            <button onClick={() => setIsCreatingTest(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold">
              + Yangi Test
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myTests.map(test => (
              <div key={test.id} className="bg-white p-6 rounded-2xl border shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-between mb-4">
                  <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold">{test.questions.length} savol</span>
                </div>
                <h3 className="text-lg font-bold mb-4">{test.title}</h3>
                <div className="flex gap-2">
                  <button className="flex-1 bg-slate-100 py-2 rounded-lg text-sm font-bold text-slate-600">Tahrirlash</button>
                  <button className="bg-red-50 text-red-500 p-2 rounded-lg"><i className="fas fa-trash"></i></button>
                </div>
              </div>
            ))}
          </div>

          {isCreatingTest && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl p-8 relative shadow-2xl">
                <button onClick={() => setIsCreatingTest(false)} className="absolute top-4 right-4 text-slate-400"><i className="fas fa-times text-xl"></i></button>
                <h2 className="text-2xl font-bold mb-6">Test Yaratish (O'qituvchi tomonidan)</h2>
                
                <div className="space-y-6">
                  <input 
                    type="text" placeholder="Test mavzusi..."
                    className="w-full text-2xl font-bold border-b-2 border-indigo-100 focus:border-indigo-600 outline-none pb-2"
                    value={newTest.title}
                    onChange={e => setNewTest({...newTest, title: e.target.value})}
                  />
                  
                  {newTest.questions?.map((q, qIdx) => (
                    <div key={qIdx} className="bg-slate-50 p-6 rounded-xl border border-slate-200">
                      <div className="flex justify-between mb-4">
                        <span className="font-bold text-slate-400">Savol #{qIdx + 1}</span>
                        <button onClick={() => {
                          const qs = [...newTest.questions!];
                          qs.splice(qIdx, 1);
                          setNewTest({...newTest, questions: qs});
                        }} className="text-red-400 hover:text-red-600"><i className="fas fa-trash"></i></button>
                      </div>
                      <input 
                        type="text" placeholder="Savol matni..."
                        className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 mb-4"
                        value={q.text}
                        onChange={e => {
                          const qs = [...newTest.questions!];
                          qs[qIdx].text = e.target.value;
                          setNewTest({...newTest, questions: qs});
                        }}
                      />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {q.options.map((opt, oIdx) => (
                          <div key={oIdx} className="flex items-center gap-2">
                            <input 
                              type="radio" name={`q-${qIdx}`} checked={q.correctAnswer === oIdx}
                              onChange={() => {
                                const qs = [...newTest.questions!];
                                qs[qIdx].correctAnswer = oIdx;
                                setNewTest({...newTest, questions: qs});
                              }}
                            />
                            <input 
                              type="text" placeholder={`Variant ${oIdx + 1}`}
                              className="w-full p-2 border rounded-lg text-sm"
                              value={opt}
                              onChange={e => {
                                const qs = [...newTest.questions!];
                                qs[qIdx].options[oIdx] = e.target.value;
                                setNewTest({...newTest, questions: qs});
                              }}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  <button onClick={addManualQuestion} className="w-full py-4 border-2 border-dashed border-slate-300 rounded-xl text-slate-500 hover:border-indigo-500 hover:text-indigo-500 transition-all">
                    + Savol qo'shish
                  </button>
                  
                  <button onClick={handleSaveTest} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold text-lg shadow-lg shadow-indigo-200">
                    Testni Saqlash
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'students' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">O'quvchilar ({myStudents.length})</h2>
            <button onClick={() => setIsAddingStudent(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold">
              + Yangi O'quvchi
            </button>
          </div>

          <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                <tr>
                  <th className="px-6 py-4">F.I.SH.</th>
                  <th className="px-6 py-4">Passport / Guvohnoma</th>
                  <th className="px-6 py-4">Telefon</th>
                  <th className="px-6 py-4">Login</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {myStudents.map(student => (
                  <tr key={student.id}>
                    <td className="px-6 py-4 font-bold text-slate-700">{student.name}</td>
                    <td className="px-6 py-4 text-slate-500 font-mono">{student.documentSeries}</td>
                    <td className="px-6 py-4 text-slate-500">{student.phone}</td>
                    <td className="px-6 py-4 text-indigo-600 font-medium">{student.username}</td>
                    <td className="px-6 py-4">
                      {student.passwordChanged ? 
                        <span className="text-green-600 text-xs bg-green-50 px-2 py-1 rounded-full">Faol</span> : 
                        <span className="text-orange-600 text-xs bg-orange-50 px-2 py-1 rounded-full">Kutilmoqda</span>
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {isAddingStudent && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-md rounded-2xl p-8 shadow-2xl relative">
                <button onClick={() => setIsAddingStudent(false)} className="absolute top-4 right-4 text-slate-400"><i className="fas fa-times"></i></button>
                <h2 className="text-2xl font-bold mb-6">O'quvchi Ma'lumotlari</h2>
                <form onSubmit={handleAddStudent} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Ism Familiya</label>
                    <input 
                      type="text" required
                      className="w-full p-2 border rounded-lg"
                      value={newStudent.name}
                      onChange={e => setNewStudent({...newStudent, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Passport / Guvohnoma seriyasi</label>
                    <input 
                      type="text" required placeholder="AA 1234567"
                      className="w-full p-2 border rounded-lg font-mono uppercase"
                      value={newStudent.documentSeries}
                      onChange={e => setNewStudent({...newStudent, documentSeries: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Telefon raqami</label>
                    <input 
                      type="tel" required placeholder="+998"
                      className="w-full p-2 border rounded-lg"
                      value={newStudent.phone}
                      onChange={e => setNewStudent({...newStudent, phone: e.target.value})}
                    />
                  </div>
                  <button className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold mt-4">Ro'yxatdan o'tkazish</button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'results' && (
        <div className="space-y-6">
          <h2 className="text-xl font-bold">Barcha natijalar va sertifikatlar</h2>
          <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 text-xs font-bold uppercase">
                <tr>
                  <th className="px-6 py-4">O'quvchi</th>
                  <th className="px-6 py-4">Test</th>
                  <th className="px-6 py-4">Foiz</th>
                  <th className="px-6 py-4">Sertifikat</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {myResults.map(res => {
                  const student = state.users.find(u => u.id === res.studentId);
                  const test = state.tests.find(t => t.id === res.testId);
                  const percentage = Math.round((res.score / res.total) * 100);
                  return (
                    <tr key={res.id}>
                      <td className="px-6 py-4">
                        <div className="font-bold">{student?.name}</div>
                        <div className="text-xs text-slate-400">{student?.documentSeries}</div>
                      </td>
                      <td className="px-6 py-4 text-slate-600">{test?.title}</td>
                      <td className="px-6 py-4">
                        <span className={`font-bold ${percentage >= 80 ? 'text-green-600' : 'text-indigo-600'}`}>{percentage}%</span>
                      </td>
                      <td className="px-6 py-4">
                        <Link to={`/certificate/${res.id}`} className="text-indigo-600 hover:underline">Ko'rish <i className="fas fa-external-link-alt ml-1 text-[10px]"></i></Link>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'billing' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {state.plans.map(p => (
            <div key={p.id} className={`p-8 rounded-3xl border-2 transition-all ${teacher.planId === p.id ? 'border-indigo-600 bg-indigo-50 ring-4 ring-indigo-100' : 'bg-white hover:border-indigo-200'}`}>
              <h3 className="text-xl font-bold mb-2">{p.name}</h3>
              <div className="text-3xl font-black mb-6">{p.price.toLocaleString()} UZS <span className="text-sm font-normal text-slate-400">/oy</span></div>
              <ul className="space-y-4 mb-8 text-slate-600">
                <li><i className="fas fa-check text-green-500 mr-2"></i> {p.studentLimit} o'quvchi limiti</li>
                <li><i className="fas fa-check text-green-500 mr-2"></i> {p.testLimit} ta test yaratish</li>
                <li><i className="fas fa-check text-green-500 mr-2"></i> Sertifikatlar barchasi bepul</li>
              </ul>
              <button className={`w-full py-3 rounded-xl font-bold ${teacher.planId === p.id ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {teacher.planId === p.id ? 'Hozirgi Tarif' : 'Tanlash'}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TeacherDashboard;
