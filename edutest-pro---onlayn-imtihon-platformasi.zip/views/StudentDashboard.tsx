import React from 'react';
import { AppState } from '../types';
import * as ReactRouterDOM from 'react-router-dom';

const { Link } = ReactRouterDOM;

interface StudentDashboardProps {
  state: AppState;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ state }) => {
  // Students only see tests from THEIR teacher
  const assignedTests = state.tests.filter(t => t.teacherId === state.currentUser?.teacherId);
  const myResults = state.attempts.filter(a => a.studentId === state.currentUser?.id);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Assalomu alaykum, {state.currentUser?.name}!</h1>
        <p className="text-gray-500">Sizga tayinlangan testlarni ko'rishingiz va topshirishingiz mumkin.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-bold flex items-center">
            <i className="fas fa-clipboard-list text-indigo-600 mr-2"></i>
            Ochiq Testlar
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assignedTests.length === 0 ? (
              <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-dashed border-gray-300 text-gray-400">
                Hozircha testlar mavjud emas
              </div>
            ) : (
              assignedTests.map(test => {
                const hasTaken = myResults.some(r => r.testId === test.id);
                return (
                  <div key={test.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition-all transform hover:-translate-y-1">
                    <h3 className="text-lg font-bold mb-2">{test.title}</h3>
                    <p className="text-sm text-gray-500 mb-6 line-clamp-2">{test.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-indigo-600 font-bold bg-indigo-50 px-2 py-1 rounded">
                        {test.questions.length} savol
                      </span>
                      {hasTaken ? (
                        <span className="text-green-600 text-sm font-bold flex items-center">
                          <i className="fas fa-check-circle mr-1"></i> Topshirildi
                        </span>
                      ) : (
                        <Link 
                          to={`/test/${test.id}`}
                          className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-indigo-700 transition-colors"
                        >
                          Boshlash
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-xl font-bold flex items-center">
            <i className="fas fa-award text-yellow-500 mr-2"></i>
            Mening Natijalarim
          </h2>
          <div className="space-y-4">
            {myResults.length === 0 ? (
              <div className="bg-white p-6 rounded-2xl text-center text-gray-500 italic">
                Siz hali test topshirmadingiz
              </div>
            ) : (
              myResults.map(attempt => {
                const test = state.tests.find(t => t.id === attempt.testId);
                const percentage = Math.round((attempt.score / attempt.total) * 100);
                return (
                  <div key={attempt.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-gray-800">{test?.title}</h4>
                      <Link to={`/certificate/${attempt.id}`} className="text-indigo-600 hover:underline text-xs">
                        Sertifikat
                      </Link>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="flex-1 bg-gray-100 h-2 rounded-full mr-3">
                        <div 
                          className={`h-full rounded-full ${percentage >= 80 ? 'bg-green-500' : 'bg-indigo-500'}`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <span className="font-bold">{percentage}%</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;