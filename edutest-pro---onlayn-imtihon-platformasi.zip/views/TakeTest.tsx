import React, { useState } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { AppState, Attempt, Question } from '../types';

const { useParams, useNavigate } = ReactRouterDOM;

interface TakeTestProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

const TakeTest: React.FC<TakeTestProps> = ({ state, updateState }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const test = state.tests.find(t => t.id === id);

  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [isFinished, setIsFinished] = useState(false);

  if (!test) return <div>Test topilmadi</div>;

  const currentQuestion = test.questions[currentQuestionIdx];

  const handleNext = () => {
    if (currentQuestionIdx < test.questions.length - 1) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      finishTest();
    }
  };

  const finishTest = () => {
    let score = 0;
    test.questions.forEach((q, idx) => {
      if (answers[idx] === q.correctAnswer) {
        score++;
      }
    });

    const attempt: Attempt = {
      id: Date.now().toString(),
      testId: test.id,
      studentId: state.currentUser!.id,
      score,
      total: test.questions.length,
      timestamp: Date.now()
    };

    updateState(prev => ({ ...prev, attempts: [...prev.attempts, attempt] }));
    setIsFinished(true);
  };

  if (isFinished) {
    const score = test.questions.filter((q, idx) => answers[idx] === q.correctAnswer).length;
    const percentage = Math.round((score / test.questions.length) * 100);

    return (
      <div className="max-w-2xl mx-auto py-12 text-center">
        <div className="bg-white p-12 rounded-3xl shadow-xl border border-gray-100">
          <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-check text-4xl"></i>
          </div>
          <h2 className="text-3xl font-bold mb-2">Imtihon Tugadi!</h2>
          <p className="text-gray-500 mb-8">Natijangiz hisoblandi</p>
          
          <div className="text-6xl font-black text-indigo-600 mb-4">{percentage}%</div>
          <p className="text-lg text-gray-700 mb-8">
            {test.questions.length} tadan {score} ta to'g'ri javob topdingiz.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => navigate('/student')}
              className="bg-gray-100 hover:bg-gray-200 px-8 py-3 rounded-xl font-bold transition-all"
            >
              Asosiy sahifa
            </button>
            <button 
              onClick={() => navigate(`/certificate/last`)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold shadow-lg transition-all"
            >
              Sertifikatni ko'rish
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{test.title}</h2>
          <p className="text-gray-500">Savol {currentQuestionIdx + 1} / {test.questions.length}</p>
        </div>
        <div className="bg-indigo-100 px-4 py-2 rounded-xl text-indigo-700 font-bold">
          {Math.round(((currentQuestionIdx) / test.questions.length) * 100)}% bajarildi
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 mb-6">
        <h3 className="text-xl font-medium mb-8 leading-relaxed">
          {currentQuestion.text}
        </h3>
        
        <div className="space-y-4">
          {currentQuestion.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => setAnswers({ ...answers, [currentQuestionIdx]: idx })}
              className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                answers[currentQuestionIdx] === idx 
                ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-200' 
                : 'border-gray-100 hover:border-gray-300 bg-gray-50'
              }`}
            >
              <div className="flex items-center">
                <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-4 font-bold border ${
                  answers[currentQuestionIdx] === idx ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-400 border-gray-200'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className={answers[currentQuestionIdx] === idx ? 'font-bold text-indigo-900' : 'text-gray-700'}>
                  {opt}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-between">
        <button 
          disabled={currentQuestionIdx === 0}
          onClick={() => setCurrentQuestionIdx(prev => prev - 1)}
          className="px-6 py-2 text-gray-400 font-bold disabled:opacity-0"
        >
          Oldingisi
        </button>
        <button 
          disabled={answers[currentQuestionIdx] === undefined}
          onClick={handleNext}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-3 rounded-xl font-bold shadow-lg disabled:opacity-50 transition-all"
        >
          {currentQuestionIdx === test.questions.length - 1 ? 'Tugatish' : 'Keyingisi'}
        </button>
      </div>
    </div>
  );
};

export default TakeTest;