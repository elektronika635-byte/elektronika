import React, { useRef } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { AppState } from '../types';

const { useParams, useNavigate } = ReactRouterDOM;

interface CertificateProps {
  state: AppState;
}

const Certificate: React.FC<CertificateProps> = ({ state }) => {
  const { attemptId } = useParams<{ attemptId: string }>();
  const navigate = useNavigate();
  const certRef = useRef<HTMLDivElement>(null);

  const attempt = attemptId === 'last' 
    ? [...state.attempts].reverse().find(a => a.studentId === state.currentUser?.id)
    : state.attempts.find(a => a.id === attemptId);

  const test = state.tests.find(t => t.id === attempt?.testId);
  const student = state.users.find(u => u.id === attempt?.studentId);
  const teacher = state.users.find(u => u.id === test?.teacherId);

  if (!attempt || !test || !student) {
    return <div className="text-center py-20">Sertifikat topilmadi</div>;
  }

  const score = Math.round((attempt.score / attempt.total) * 100);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8 flex justify-between items-center print:hidden">
        <button onClick={() => navigate(-1)} className="text-indigo-600 font-bold">
          <i className="fas fa-arrow-left mr-2"></i> Orqaga
        </button>
        <button 
          onClick={handlePrint}
          className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold shadow hover:bg-indigo-700"
        >
          <i className="fas fa-print mr-2"></i> Chop etish
        </button>
      </div>

      <div 
        ref={certRef}
        className="relative bg-white border-[16px] border-indigo-900 p-16 shadow-2xl min-h-[600px] flex flex-col items-center justify-center text-center overflow-hidden"
      >
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-32 h-32 border-t-8 border-l-8 border-yellow-500 -m-4"></div>
        <div className="absolute bottom-0 right-0 w-32 h-32 border-b-8 border-r-8 border-yellow-500 -m-4"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-5 pointer-events-none">
            <i className="fas fa-graduation-cap text-[30rem]"></i>
        </div>

        <div className="z-10 w-full">
          <div className="flex items-center justify-center mb-8">
            <i className="fas fa-award text-7xl text-indigo-900"></i>
          </div>
          
          <h1 className="text-4xl font-serif font-black text-indigo-900 tracking-widest uppercase mb-4">
            Muvaffaqiyat Sertifikati
          </h1>
          <p className="text-xl text-gray-500 font-serif italic mb-12">Ushbu sertifikat topshiriladi:</p>

          <h2 className="text-5xl font-bold text-gray-800 border-b-2 border-indigo-100 pb-2 mb-12 inline-block px-12">
            {student.name}
          </h2>

          <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed mb-12">
            <b>{test.title}</b> fanidan o'tkazilgan onlayn imtihonda faol ishtirok etib, 
            umumiy natijadan <b>{score}%</b> to'plagani va o'z bilimini muvaffaqiyatli tasdiqlagani uchun.
          </p>

          <div className="flex flex-col md:flex-row justify-between items-end mt-12 gap-12 w-full max-w-2xl mx-auto px-4">
            <div className="text-center flex flex-col items-center">
              <div className="border-b border-gray-400 w-48 mb-2 font-serif italic text-gray-500">Imzo</div>
              <span className="font-bold text-indigo-900">{teacher?.name}</span>
              <span className="text-xs text-gray-400 uppercase">O'qituvchi</span>
            </div>
            
            <div className="text-center flex flex-col items-center">
              <div className="w-24 h-24 border-4 border-indigo-900 rounded-full flex items-center justify-center text-xs font-bold text-indigo-900 opacity-30 mb-2">
                PLATFORMA MUHRI
              </div>
              <span className="text-xs text-gray-400 uppercase">Sana: {new Date(attempt.timestamp).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-8 text-center text-gray-400 text-sm italic print:hidden">
        ID: {attempt.id} | EduTest Pro xavfsiz imtihon tizimi orqali yaratilgan
      </div>
    </div>
  );
};

export default Certificate;