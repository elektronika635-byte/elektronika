
import React, { useState } from 'react';
import { AppState, User } from '../types';

interface ChangePasswordProps {
  updateState: (updater: (prev: AppState) => AppState) => void;
  currentUser: User;
}

const ChangePassword: React.FC<ChangePasswordProps> = ({ updateState, currentUser }) => {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      setError('Parol kamida 6 ta belgidan iborat bo\'lishi kerak');
      return;
    }
    if (password !== confirm) {
      setError('Parollar mos kelmadi');
      return;
    }

    updateState(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === currentUser.id ? { ...u, password, passwordChanged: true } : u),
      currentUser: { ...currentUser, passwordChanged: true }
    }));
  };

  return (
    <div className="max-w-md mx-auto mt-20">
      <div className="bg-white p-8 rounded-3xl shadow-xl border">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-key text-3xl"></i>
          </div>
          <h2 className="text-2xl font-bold">Xavfsizlikni ta'minlang</h2>
          <p className="text-slate-500 mt-2">Bu sizning birinchi kirishingiz. Iltimos, o'z parolingizni belgilang.</p>
        </div>

        {error && <div className="bg-red-50 text-red-500 p-3 rounded-lg text-sm mb-6">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Yangi parol</label>
            <input 
              type="password" required
              className="w-full p-3 border rounded-xl"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Parolni tasdiqlang</label>
            <input 
              type="password" required
              className="w-full p-3 border rounded-xl"
              value={confirm}
              onChange={e => setConfirm(e.target.value)}
            />
          </div>
          <button className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 mt-4">
            Parolni Saqlash va Kirish
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChangePassword;
