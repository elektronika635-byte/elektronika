
import React, { useState } from 'react';
import { User, Role, AppState } from '../types';

interface LoginProps {
  users: User[];
  onLogin: (user: User) => void;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

const Login: React.FC<LoginProps> = ({ users, onLogin, updateState }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      if (user.isActive === false) {
        setError('Sizning profilingiz bloklangan. Admin bilan bog\'laning.');
        return;
      }
      onLogin(user);
    } else {
      setError('Login yoki parol noto\'g\'ri');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (users.some(u => u.username === username)) {
      setError('Ushbu foydalanuvchi nomi band');
      return;
    }

    const newUser: User = {
      id: Date.now().toString(),
      name,
      username,
      password,
      phone,
      role: Role.TEACHER,
      planId: 'free',
      isActive: true,
      passwordChanged: true
    };

    updateState(prev => ({ ...prev, users: [...prev.users, newUser] }));
    onLogin(newUser);
  };

  return (
    <div className="max-w-md mx-auto mt-12">
      <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className={`fas ${isRegister ? 'fa-user-plus' : 'fa-lock'} text-3xl`}></i>
          </div>
          <h1 className="text-2xl font-bold text-gray-800">
            {isRegister ? "O'qituvchi ro'yxatdan o'tishi" : "Tizimga kirish"}
          </h1>
          <p className="text-gray-500 mt-2">EduTest Pro platformasiga xush kelibsiz</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-6 flex items-center">
            <i className="fas fa-exclamation-circle mr-2"></i>
            {error}
          </div>
        )}

        <form onSubmit={isRegister ? handleRegister : handleLogin} className="space-y-4">
          {isRegister && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">F.I.SH.</label>
                <input
                  type="text" required
                  className="w-full px-4 py-2 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Ism va Familiyangiz"
                  value={name}
                  onChange={e => setName(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                <input
                  type="tel" required
                  className="w-full px-4 py-2 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="+998"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                />
              </div>
            </>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Foydalanuvchi nomi</label>
            <input
              type="text" required
              className="w-full px-4 py-2 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none"
              placeholder="Username"
              value={username}
              onChange={e => setUsername(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Parol</label>
            <input
              type="password" required
              className="w-full px-4 py-2 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none"
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>
          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg transition-all"
          >
            {isRegister ? "Ro'yxatdan o'tish" : "Kirish"}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button 
            onClick={() => { setIsRegister(!isRegister); setError(''); }}
            className="text-indigo-600 hover:underline text-sm font-medium"
          >
            {isRegister ? "Sizda hisob bormi? Kirish" : "Hisobingiz yo'qmi? Ro'yxatdan o'tish"}
          </button>
        </div>

        {!isRegister && (
          <div className="mt-8 pt-6 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-400">
              Admin: admin / 123 | O'qituvchi: ali / 123
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Login;
