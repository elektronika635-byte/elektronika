
import React, { useState } from 'react';
import { AppState, Role, User, Plan } from '../types';

interface AdminDashboardProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ state, updateState }) => {
  const [activeTab, setActiveTab] = useState<'teachers' | 'plans' | 'stats'>('teachers');
  const [showUserModal, setShowUserModal] = useState(false);
  const [showPlanModal, setShowPlanModal] = useState(false);
  
  // New User Form
  const [newUser, setNewUser] = useState({ name: '', username: '', password: '', phone: '', planId: 'free' });
  // New Plan Form
  const [newPlan, setNewPlan] = useState({ name: '', price: 0, studentLimit: 10, testLimit: 5 });

  const teachers = state.users.filter(u => u.role === Role.TEACHER);
  const studentsCount = state.users.filter(u => u.role === Role.STUDENT).length;

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (state.users.some(u => u.username === newUser.username)) {
      alert("Bu username allaqachon mavjud!");
      return;
    }
    const user: User = {
      id: Date.now().toString(),
      ...newUser,
      role: Role.TEACHER,
      isActive: true,
      passwordChanged: true
    };
    updateState(prev => ({ ...prev, users: [...prev.users, user] }));
    setShowUserModal(false);
    setNewUser({ name: '', username: '', password: '', phone: '', planId: 'free' });
  };

  const handleAddPlan = (e: React.FormEvent) => {
    e.preventDefault();
    const plan: Plan = {
      id: newUser.name.toLowerCase().replace(/\s+/g, '-'),
      ...newPlan
    };
    updateState(prev => ({ ...prev, plans: [...prev.plans, plan] }));
    setShowPlanModal(false);
    setNewPlan({ name: '', price: 0, studentLimit: 10, testLimit: 5 });
  };

  const toggleUserStatus = (id: string) => {
    updateState(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === id ? {...u, isActive: !u.isActive} : u)
    }));
  };

  const deleteUser = (id: string) => {
    if (confirm('Ushbu foydalanuvchini o\'chirish barcha unga tegishli ma\'lumotlarni ham yo\'q qilishi mumkin. Rostdan ham o\'chirmoqchimisiz?')) {
      updateState(prev => ({
        ...prev,
        users: prev.users.filter(u => u.id !== id)
      }));
    }
  };

  const deletePlan = (id: string) => {
    if (state.users.some(u => u.planId === id)) {
      alert("Ushbu tarifda foydalanuvchilar mavjud, o'chirish imkonsiz!");
      return;
    }
    updateState(prev => ({
      ...prev,
      plans: prev.plans.filter(p => p.id !== id)
    }));
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900">Admin Panel</h1>
          <p className="text-slate-500">Platforma tizimi va foydalanuvchilar boshqaruvi</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl shadow-sm border overflow-x-auto max-w-full">
          {(['teachers', 'plans', 'stats'] as const).map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)} 
              className={`px-6 py-2 rounded-xl font-bold transition-all whitespace-nowrap ${activeTab === tab ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-600 hover:bg-slate-50'}`}
            >
              {tab === 'teachers' ? "O'qituvchilar" : tab === 'plans' ? "Tariflar" : "Statistika"}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'teachers' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">O'qituvchilar Ro'yxati</h2>
            <button 
              onClick={() => setShowUserModal(true)}
              className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold shadow-lg hover:bg-indigo-700"
            >
              + O'qituvchi qo'shish
            </button>
          </div>
          <div className="bg-white rounded-3xl border shadow-sm overflow-hidden overflow-x-auto">
            <table className="w-full text-left min-w-[800px]">
              <thead className="bg-slate-50 text-slate-400 text-xs font-bold uppercase tracking-wider">
                <tr>
                  <th className="px-8 py-5">O'qituvchi</th>
                  <th className="px-8 py-5">Username</th>
                  <th className="px-8 py-5">Telefon</th>
                  <th className="px-8 py-5">Tarif</th>
                  <th className="px-8 py-5">Holat</th>
                  <th className="px-8 py-5">Harakat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teachers.map(t => (
                  <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-5 font-bold text-slate-700">{t.name}</td>
                    <td className="px-8 py-5 text-slate-500 font-mono text-sm">{t.username}</td>
                    <td className="px-8 py-5 text-slate-500">{t.phone || "-"}</td>
                    <td className="px-8 py-5">
                      <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold uppercase">{t.planId}</span>
                    </td>
                    <td className="px-8 py-5">
                      <button 
                        onClick={() => toggleUserStatus(t.id)} 
                        className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${t.isActive ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}
                      >
                        {t.isActive ? 'Faol' : 'Bloklangan'}
                      </button>
                    </td>
                    <td className="px-8 py-5">
                      <button onClick={() => deleteUser(t.id)} className="text-red-400 hover:text-red-600 p-2 transition-colors">
                        <i className="fas fa-trash-alt"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'plans' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Tizim Tariflari</h2>
            <button 
              onClick={() => setShowPlanModal(true)}
              className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold shadow-lg hover:bg-indigo-700"
            >
              + Yangi Tarif
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {state.plans.map(plan => (
              <div key={plan.id} className="bg-white p-8 rounded-3xl border shadow-sm relative group hover:border-indigo-200 transition-all overflow-hidden">
                <div className="flex justify-between items-start mb-6">
                  <h3 className="text-2xl font-black text-slate-800">{plan.name}</h3>
                  <button onClick={() => deletePlan(plan.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
                <div className="text-4xl font-bold text-indigo-600 mb-8">{plan.price.toLocaleString()} <span className="text-base font-normal text-slate-400">UZS</span></div>
                <div className="space-y-4 text-slate-500 mb-6">
                  <div className="flex justify-between items-center bg-slate-50 p-3 rounded-xl">
                    <span>O'quvchi limiti:</span> 
                    <span className="font-bold text-slate-800">{plan.studentLimit}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-50 p-3 rounded-xl">
                    <span>Test limiti:</span> 
                    <span className="font-bold text-slate-800">{plan.testLimit}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'stats' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: "O'qituvchilar", value: teachers.length, icon: "fa-chalkboard-teacher", color: "indigo" },
            { label: "O'quvchilar", value: studentsCount, icon: "fa-users", color: "green" },
            { label: "Barcha Testlar", value: state.tests.length, icon: "fa-file-alt", color: "orange" },
            { label: "Urinishlar", value: state.attempts.length, icon: "fa-check-double", color: "purple" }
          ].map((card, i) => (
            <div key={i} className="bg-white p-8 rounded-3xl border shadow-sm flex flex-col items-center text-center">
              <div className={`w-14 h-14 bg-${card.color}-100 text-${card.color}-600 rounded-2xl flex items-center justify-center mb-4 text-xl`}>
                <i className={`fas ${card.icon}`}></i>
              </div>
              <div className="text-slate-400 text-xs font-bold uppercase mb-1">{card.label}</div>
              <div className={`text-4xl font-black text-${card.color}-600`}>{card.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* MODALS */}
      {showUserModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl relative">
            <button onClick={() => setShowUserModal(false)} className="absolute top-6 right-6 text-slate-400 hover:text-slate-600">
              <i className="fas fa-times text-xl"></i>
            </button>
            <h2 className="text-2xl font-bold mb-6">O'qituvchi Qo'shish</h2>
            <form onSubmit={handleAddUser} className="space-y-4">
              <input type="text" placeholder="F.I.SH." required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} />
              <input type="text" placeholder="Username" required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newUser.username} onChange={e => setNewUser({...newUser, username: e.target.value})} />
              <input type="password" placeholder="Parol" required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} />
              <input type="tel" placeholder="Telefon" className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newUser.phone} onChange={e => setNewUser({...newUser, phone: e.target.value})} />
              <select className="w-full p-3 border rounded-xl outline-none" value={newUser.planId} onChange={e => setNewUser({...newUser, planId: e.target.value})}>
                {state.plans.map(p => <option key={p.id} value={p.id}>{p.name} ({p.price} UZS)</option>)}
              </select>
              <button className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg mt-4">Saqlash</button>
            </form>
          </div>
        </div>
      )}

      {showPlanModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl relative">
            <button onClick={() => setShowPlanModal(false)} className="absolute top-6 right-6 text-slate-400 hover:text-slate-600">
              <i className="fas fa-times text-xl"></i>
            </button>
            <h2 className="text-2xl font-bold mb-6">Yangi Tarif Yarating</h2>
            <form onSubmit={handleAddPlan} className="space-y-4">
              <input type="text" placeholder="Tarif nomi" required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newPlan.name} onChange={e => setNewPlan({...newPlan, name: e.target.value})} />
              <input type="number" placeholder="Narxi (UZS)" required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newPlan.price} onChange={e => setNewPlan({...newPlan, price: Number(e.target.value)})} />
              <input type="number" placeholder="O'quvchi limiti" required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newPlan.studentLimit} onChange={e => setNewPlan({...newPlan, studentLimit: Number(e.target.value)})} />
              <input type="number" placeholder="Test limiti" required className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newPlan.testLimit} onChange={e => setNewPlan({...newPlan, testLimit: Number(e.target.value)})} />
              <button className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg mt-4">Tarifni qo'shish</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
