import React from 'react';
import { User, Role } from '../types';
import * as ReactRouterDOM from 'react-router-dom';

const { Link, useNavigate } = ReactRouterDOM;

interface NavbarProps {
  currentUser: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentUser, onLogout }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  return (
    <nav className="bg-indigo-600 text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <i className="fas fa-graduation-cap text-2xl"></i>
          <span className="text-xl font-bold tracking-tight">EduTest Pro</span>
        </Link>
        
        {currentUser && (
          <div className="flex items-center space-x-4">
            <div className="hidden md:block">
              <span className="text-sm opacity-80">{currentUser.role === Role.TEACHER ? 'O\'qituvchi' : 'O\'quvchi'}:</span>
              <span className="ml-2 font-medium">{currentUser.name}</span>
            </div>
            <button 
              onClick={handleLogout}
              className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition-colors text-sm"
            >
              <i className="fas fa-sign-out-alt mr-2"></i>
              Chiqish
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;